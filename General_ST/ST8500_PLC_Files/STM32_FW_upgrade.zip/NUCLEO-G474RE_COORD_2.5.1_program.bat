@echo off

set CORTEX=NUCLEO-G474RE_COORD_2.5.1.hex

PATH C:\Program Files\STMicroelectronics\STM32Cube\STM32CubeProgrammer\bin

STM32_Programmer_CLI.exe -c port=SWD -w imgs\%CORTEX%

pause> nul | set /p "=Press ENTER to continue"