In order to use the Custom External Loader with STM32CubeProgrammer, copy the generated "W25Q16JV_EVLKST8500GH-2-G0.stldr", "W25Q16JV_EVLKST8500GH-2-G4.stldr" and "W25Q16JV_EVLKST8500GH-2-L4.stldr" files
to the "X:\Program Files\STMicroelectronics\STM32Cube\STM32CubeProgrammer\bin\ExternalLoader" folder.

External Loaders named "W25Q16JV_EVLKST8500GH-2-G0", "W25Q16JV_EVLKST8500GH-2-G4" and "W25Q16JV_EVLKST8500GH-2-L4" shall appear in the External Loader list inside STM32CubeProgrammer.

Select the External loader according to the board in use:
	- NUCLEO-G070RB -> W25Q16JV_EVLKST8500GH-2-G0
	- NUCLEO-G474RE -> W25Q16JV_EVLKST8500GH-2-G4
	- NUCLEO-L476RG -> W25Q16JV_EVLKST8500GH-2-L4

For further details about the usage of the External Loader, see AN5715 section 8 (STM32 SPI Flash programming).

Tested with STM32CubeProgrammer v2.14.0